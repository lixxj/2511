package q14.gitlab;

public enum PermissionsLevel {
    OWNER,
    MAINTAINER,
    DEVELOPER,
    REPORTER,
    NONE    
}