// A simple Java Program

class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, Welcome to COMP2511!");
        System.out.println("XJ test");
    }
}
