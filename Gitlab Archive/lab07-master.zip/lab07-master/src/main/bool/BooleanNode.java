package bool;

/**
 * A boolean BooleanNode.
 * @author Nick Patrikeos + @your name
 * 
 * Feel free to change this to an abstract class/interface as you see fit.
 */
public abstract class BooleanNode {
    public abstract boolean evaluate();
    public abstract String prettyPrint();
}