package q13;

import java.time.LocalDateTime;

public class LiveArticleSystem {

    public String createLiveArticle(LocalDateTime timeCreated) {
        return null;
    }

    public String createPost(String articleID, LocalDateTime timeCreated, String postTitle, String postContent) {
        return null;
    }

    public void updatePost(String articleID, String postID, String newContent) {
        
    }

    public void deletePost(String articleID, String postID) {

    }

    public void addComment(String articleID, String postID, String comment) {
        
    }

}