package dungeonmania.CollectableEntity;

import dungeonmania.util.Position;

public class SunStone extends CollectableEntity {
    public SunStone(Position position, String type) {
        super(position, type);
    }
}
