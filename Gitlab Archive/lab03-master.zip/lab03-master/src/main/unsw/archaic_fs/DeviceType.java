package unsw.archaic_fs;

public enum DeviceType {
    FILE,
    FOLDER,
}
