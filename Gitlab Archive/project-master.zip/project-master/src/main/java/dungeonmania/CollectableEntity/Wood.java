package dungeonmania.CollectableEntity;

import dungeonmania.util.Position;

public class Wood extends CollectableEntity {
    
    // Constructor
    public Wood(Position position, String type) {
        super(position, type);
    }
    
}
