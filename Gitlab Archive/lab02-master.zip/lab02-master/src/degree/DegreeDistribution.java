package degree;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Comparator;

public class DegreeDistribution {

    public JSONObject distribute(String degreesFilename, String studentsFilename) {
        return null;
    }
}