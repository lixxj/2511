package unsw.set.fruit;

public interface Fruit {
    public String getName();
}
