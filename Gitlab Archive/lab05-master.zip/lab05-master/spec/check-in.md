## Week 05 - Core Blog - Check-in

Make a public blog post on WebCMS and in it take some time to reflect on how you think you are going in the course. 

It's a good time to take a brief pause and take stock of where we're at before we move into the second half of the term. 

* How do you think you are going in the course?
* What has been the most difficult/challenging part of the course so far?
* Look back at the goals you set in Week 1. How are they tracking?
* What is one thing you want to improve for the second half of the term?

Post a link to your blog with a summary comment on the Blogging Megathread in the forum. Read through at least two other people's posts and leave a comment as a reply in the thread with your thoughts.