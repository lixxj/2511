package dungeonmania.CollectableEntity;

import dungeonmania.util.Position;

public class Arrow extends CollectableEntity {
    // Constructor
    public Arrow(Position position, String type) {
        super(position, type);
    }
}
