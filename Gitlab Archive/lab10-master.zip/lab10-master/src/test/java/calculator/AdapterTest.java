package calculator;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import unsw.calculator.view.Evaluator;
import unsw.calculator.view.EvaluatorAdapter;

public class AdapterTest {
    /*@Test
    public void testSimpleExpression() {
        Evaluator e = new EvaluatorAdapter();
        assertEquals(-3, e.evaluate("1 + 2 - 3 * 10 / 5"));
    }
    
    @Test
    public void testSimpleExpression2() {
        Evaluator e = new EvaluatorAdapter();
        assertEquals(19, e.evaluate("10 + 10 / 2 * 3 - 6"));
    }*/
}