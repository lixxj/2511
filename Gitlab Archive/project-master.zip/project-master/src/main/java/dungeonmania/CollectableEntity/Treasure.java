package dungeonmania.CollectableEntity;

import dungeonmania.util.Position;

public class Treasure extends CollectableEntity {
    // Constructor
    public Treasure(Position position, String type) {
        super(position, type);
    }
}
