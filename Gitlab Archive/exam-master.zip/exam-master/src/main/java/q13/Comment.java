package q13;

public class Comment {
    String commentContent;

    public Comment(String commentContent) {
        this.commentContent = commentContent;
    }
}
